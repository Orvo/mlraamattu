$(function(){
	
	$('nav.navbar a').click(function()
	{
		$('nav.navbar li').removeClass('active');
		$(this).parent().addClass('active');
	});

	$('.nav-tabs a, .prevent-default').click(function(e)
	{
		e.preventDefault();
	});
	
});
