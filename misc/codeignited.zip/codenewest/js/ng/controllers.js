
/*
 * Controllers
 */

app.controller('IndexController', function($scope, $window, $location, $routeParams, QuestionsModel)
{
	QuestionsModel.query(function(data)
	{
		$scope.questions = data;
		
		angular.forEach($scope.questions, function(value, key)
		{
			if(value.type == "CHOICE")
			{
				$scope.questions[key].type = "Yksivalinta";
			}
			else if(value.type == "MULTI")
			{
				$scope.questions[key].type = "Monivalinta";
			}
			else if(value.type == "TEXT")
			{
				$scope.questions[key].type = "Teksti";
			}
			else if(value.type == "TEXTAREA")
			{
				$scope.questions[key].type = "Pitkä teksti";
			}
			else if(value.type == "MULTITEXT")
			{
				$scope.questions[key].type = "Moniteksti";
			}
		});
	});
		
	$scope.sortableOptions = {
		axis: 'y',
	};
});

app.controller('SeriesController', function($scope, $window, $location, $routeParams, SeriesModel)
{
	$scope.series = SeriesModel.query(function(data)
	{
		
	});
		
	$scope.sortableOptions = {
		axis: 'y',
	};
});

app.controller('SeriesFormController', function($scope, $window, $location, $routeParams, SeriesModel)
{
	$scope.id = $routeParams.id;
});

app.controller('TestsFormController', function($scope, $window, $location, $routeParams, TestsModel)
{
	TestsModel.get({id: 1}, function(data)
	{
		console.log(data);
		$scope.test = data;
		$scope.questions = data.questions;

		/*[
			{
				id: 1,
				type: 'MULTI',
				title: 'Hello',
				subtitle: 'World',
				choices: [
					{ id: 1, title: 'Potato', is_correct: true, },
					{ id: 2, title: 'Banana', is_correct: false, },
				],
				answer: '',
				answers: [
					{ title: '', },
					{ title: '', },
				],
			},
			{
				id: 2,
				type: 'CHOICE',
				title: 'Potato',
				subtitle: 'World',
				choices: [
					{ id: 3, title: 'Tomato', is_correct: true, },
					{ id: 4, title: 'Batman', is_correct: false, },
				],
				answer: '',
				answers: [
					{ title: '', },
					{ title: '', },
				],
			}
		];*/
	});

	

	$scope.edit = function(id)
	{
		$('.question div.edit').hide();
		$('#question-' + id + ' div.edit').show();
	}

	$scope.cancel = function()
	{
		$('.question div.edit').hide();
	}

	$scope.add_question = function()
	{
		$scope.questions.push({
			type: 'MULTI',
			title: 'Hello',
			subtitle: 'World',
			choices: [],
		});
	};

	$scope.removeChoice = function(q, c)
	{
		$scope.questions[q].choices.splice(c, 1);
	}

	$scope.addChoice = {
		do: function(key, qid)
		{
			var text = $scope.addChoice.text.trim();

			if(text.length > 0)
			{
				$scope.questions[key].choices.push({
					title: text,
				});
			}

			$scope.addChoice.text = '';
		},
		text: '',
	};

	$scope.sortableOptions = {
		axis: 'y',
		start: function(e, ui)
		{
			console.log(e, ui);
		},
		update: function(e, ui)
		{
			console.log(e, ui);
			if(ui.item.sortable.model)
			{

			}
		},
	};
});

app.controller('NavbarController', function($rootScope, $scope, $window, $location, $routeParams)
{
	// $scope.categories = CategoryModel.query(null, null, function(data)
	// {
	// 	if(data.status == 401)
	// 	{
	// 		$window.location = '/login';
	// 	}
	// });

	// $scope.changeCategory = function(id, $event)
	// {
	// 	if($location.path() != '/article/') return;

	// 	$event.preventDefault();

	// 	$rootScope.$broadcast('hello', {
	// 		id: id
	// 	});
	// }
});
