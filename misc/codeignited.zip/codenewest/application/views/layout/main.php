<!DOCTYPE html>
<html>
<head>
	<title>M7R</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
	<link rel="stylesheet" href="/css/main.css">
</head>
	<body>
		<div id="login-status">
			<?php if(@$AUTH->logged_in): ?>
				Terve, <?php echo @$AUTH->email; ?>!
				<?php if($AUTH->user->access == 1): ?>
					<a href="/admin">Ylläpito</a>
				<?php endif; ?>
				<a href="/logout">Kirjaudu ulos!</a>
			<?php else: ?>
				<a href="/login">Kirjaudu sisään</a>
			<?php endif; ?>
		</div>
		<div class="content">
			<?php echo $_PAGE_CONTENT; ?>
		</div>
	</body>
</html>

