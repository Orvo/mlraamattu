<a href="/" class="btn btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Takaisin pääsivulle</a>
<form action="/test/<?php echo $test_id; ?> " method="post" class="test-form form-horizontal">
	<div class="form-group">
		<h1 class="test-title"><?php echo $test->title; ?></h1>
		<?php if($test->description && strlen($test->description) > 0): ?>
			<div class="test-description"><?php echo $test->description; ?></div>
		<?php endif; ?>
		<input type="hidden" name="test_id" value="<?php echo $test_id; ?>">
	</div>
	
	<fieldset class="questions">
		<legend>Kysymykset</legend>
		<?php foreach($questions as $question): ?>
			<div class="question">
				<input type="hidden" name="questions[]" value="<?php echo $question->id; ?>">
				<div class="form-group">
					<div class="title">
						<?php if(is_array($question->validation) && $question->validation['correct'] === true): ?>
							<p class="pull-right" style="color:#329f07"><span class="glyphicon glyphicon-ok"></span> Oikein!</p>
						<?php elseif(is_array($question->validation) && $question->validation['correct'] === false && @$question->validation['partial'] > 0): ?>
							<p class="pull-right" style="color:#D9B614">
								<span class="glyphicon glyphicon-remove"></span>
								<?php if($question->type == "MULTITEXT"): ?>
									<?php echo $question->validation['partial'] ?> oikein!
								<?php else: ?>
									Osittain oikein!
								<?php endif; ?>
							</p>
						<?php elseif($question->validation === false || is_array($question->validation) && $question->validation['correct'] === false): ?>
							<p class="pull-right" style="color:#af000d"><span class="glyphicon glyphicon-remove"></span> Väärin!</p>
						<?php endif; ?>
						
						<?php echo $question->number . '. ' . $question->title; ?>
					</div>
					<?php if($question->subtitle and strlen($question->subtitle) > 0): ?>
						<p class="subtitle"><?php echo $question->subtitle; ?></p>
					<?php endif; ?>
					<div class="answer">
						<?php
							switch($question->type): 
								case 'MULTI':
							?>
								<?php foreach($question->choices as $choice): ?>
									<div class="checkbox">
										<label>
											<input type="checkbox" name="answer-<?php echo $question->id; ?>[]" value="<?php echo $choice->id; ?>"<?php echo @$question->answers && in_array($choice->id, $question->answers) ? ' checked' : ''?>>
											<?php echo $choice->text; ?> / <?php echo $choice->is_correct; ?>
										</label>
									</div>
								<?php endforeach; ?>
							<?php
								break;
								//--------------------------------------------------------------------------
								case 'CHOICE':
							?>
								<?php foreach($question->choices as $choice): ?>
									<div class="radio">
										<label>
											<input type="radio" name="answer-<?php echo $question->id; ?>" value="<?php echo $choice->id; ?>"<?php echo @$question->answers && $question->answers == $choice->id ? ' checked' : ''?>>
											<?php echo $choice->text; ?> / <?php echo $choice->is_correct; ?>
										</label>
									</div>
								<?php endforeach; ?>
							<?php
								break;
								//--------------------------------------------------------------------------
								case 'TEXT':
							?>
								<input type="text" class="form-control" name="answer-<?php echo $question->id; ?>" value="<?php echo @$question->answers ?>">
							<?php
								break;
								//--------------------------------------------------------------------------
								case 'MULTITEXT':
							?>
								<div class="multitext">
									<?php for($i=0; $i < $question->num_answers; ++$i): ?>
										<div class="row">
											<label for="answer-<?php echo $question->id .'-'. $i; ?>" class="col-xs-1 control-label"><?php echo $i+1; ?>.</label>
											<div class="col-xs-11">
												<input type="text" class="form-control" name="answer-<?php echo $question->id; ?>[]" value="<?php echo @$question->answers[$i] ?>" id="answer-<?php echo $question->id .'-'. $i; ?>">
											</div>
										</div>
									<?php endfor; ?>
								</div>
							<?php
								break;
								//--------------------------------------------------------------------------
								case 'TEXTAREA':
							?>
								<textarea class="form-control" name="answer-<?php echo $question->id; ?>"><?php echo @$question->answers ?></textarea>
							<?php
								break;
							?>
						<?php endswitch; ?>
					</div>
				</div>

			</div>
		<?php endforeach; ?>
	</fieldset>
	
	<?php if(!@$AUTH->logged_in): ?>
		<fieldset>
			<legend>Rekisteröidy</legend>
			<p style="padding-bottom:1em">
				Jatkaaksesi sinun tulee rekisteröityä, jotta järjestelmä voi pitää kirjaa vastauksistasi ja sinulle voidaan antaa palautetta.
			</p>
			<?php if(count(@$errors) > 0): ?>
				<div class="alert alert-danger" role="alert">
					<b>Hupsis!</b> Rekisteröinnissä tapahtui virhe:
					<ul>
						<?php foreach($errors as $error): ?>
							<li><?php echo $error; ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
			<div class="form-group">
				<label for="user-email" class="control-label col-xs-3">Sähköposti</label>
				<div class="col-xs-6">
					<input type="text" class="form-control" id="user-email" name="user-email" value="<?php echo @$fields['email']; ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="user-password1" class="control-label col-xs-3">Salasana</label>
				<div class="col-xs-6">
					<input type="password" class="form-control" id="user-password1" name="user-password1">
				</div>
			</div>
			<div class="form-group">
				<label for="user-password2" class="control-label col-xs-3">Salasana Uudestaan</label>
				<div class="col-xs-6">
					<input type="password" class="form-control" id="user-password2" name="user-password2">
				</div>
			</div>
		</fieldset>
	<?php endif; ?>
	
	<hr>
	<div class="form-group">
		<button class="btn btn-primary btn-block">
			Tarkista vastaukset
			<?php if(!@$AUTH->logged_in): ?>
				ja rekisteröidy
			<?php endif; ?>
		</button>
	</div>
</form>