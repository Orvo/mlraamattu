<?php defined('BASEPATH') OR exit('No direct script access allowed') ?>
<div class="question">
	<input type="hidden" name="questions[]" value="<?php echo $question->id; ?>">
	<div class="title">
	
		<?php if(is_array($validation) && $validation['correct'] === true): ?>
			<p class="pull-right" style="color:#329f07"><span class="glyphicon glyphicon-ok"></span> Oikein!</p>
		<?php elseif(is_array($validation) && $validation['correct'] === false && @$validation['partial'] > 0): ?>
			<p class="pull-right" style="color:#D9B614"><span class="glyphicon glyphicon-remove"></span> Osittain oikein!</p>
		<?php elseif($validation === false || is_array($validation) && $validation['correct'] === false): ?>
			<p class="pull-right" style="color:#af000d"><span class="glyphicon glyphicon-remove"></span> Väärin!</p>
		<?php endif; ?>
		
		<?php echo $question->number . '. ' . $question->title; ?>
	</div>
	<?php if($question->subtitle and strlen($question->subtitle) > 0): ?>
		<p class="subtitle"><?php echo $question->subtitle; ?></p>
	<?php endif; ?>
	<div class="answer">
		<?php
			switch($question->type): 
				case 'MULTI':
			?>
				<?php foreach($question->choices as $choice): ?>
					<div class="checkbox">
						<label>
							<input type="checkbox" name="answer-<?php echo $question->id; ?>[]" value="<?php echo $choice->id; ?>"<?php echo @$answers && in_array($choice->id, $answers) ? ' checked' : ''?>>
							<?php echo $choice->text; ?> / <?php echo $choice->is_correct; ?>
						</label>
					</div>
				<?php endforeach; ?>
			<?php
				break;
				case 'CHOICE':
			?>
				<?php foreach($question->choices as $choice): ?>
					<div class="radio">
						<label>
							<input type="radio" name="answer-<?php echo $question->id; ?>" value="<?php echo $choice->id; ?>"<?php echo @$answers && $answers == $choice->id ? ' checked' : ''?>>
							<?php echo $choice->text; ?> / <?php echo $choice->is_correct; ?>
						</label>
					</div>
				<?php endforeach; ?>
			<?php
				break;
				case 'TEXT':
			?>
				<div class="form-group">
					<input type="text" class="form-control" name="answer-<?php echo $question->id; ?>" value="<?php echo @$answers ?>">
				</div>
			<?php
				break;
				case 'MULTITEXT':
			?>
				<div class="form-group multitext">
					<?php for($i=0; $i<$question->num_answers; ++$i): ?>
						<div class="row">
							<label for="answer-<?php echo $question->id .'-'. $i; ?>" class="col-xs-1 control-label"><?php echo $i+1; ?>.</label>
							<div class="col-xs-11">
								<input type="text" class="form-control" name="answer-<?php echo $question->id; ?>[]" value="<?php echo @$answers[$i] ?>" id="answer-<?php echo $question->id .'-'. $i; ?>">
							</div>
						</div>
					<?php endfor; ?>
				</div>
			<?php
				break;
				case 'TEXTAREA':
			?>
				<div class="form-group">
					<textarea class="form-control" name="answer-<?php echo $question->id; ?>"><?php echo @$answers ?></textarea>
				</div>
			<?php
				break;
			?>
		<?php endswitch; ?>
	</div>
</div>