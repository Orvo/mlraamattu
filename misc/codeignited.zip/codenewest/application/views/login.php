<a href="/" class="btn btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Takaisin pääsivulle</a>

<div style="width:80%;margin:0 auto;text-align:center;padding-top:80px">
	<h1 style="padding-bottom:0.5em">Kirjaudu sisään</h1>
	<form action="/login" method="post" class="form-horizontal">
		<?php if(@$login_success === false): ?>
			<div class="alert alert-danger" role="alert"><b>Hupsis!</b> Väärä sähköposti tai salasana!</div>
		<?php endif; ?>
		<div class="form-group">
			<input type="text" id="email" class="form-control input-lg" name="email" placeholder="Sähköposti">
		</div>
		<div class="form-group">
			<input type="password" id="password" class="form-control input-lg" name="password" placeholder="Salasana">
		</div>
		<div class="form-group">
			<button class="btn btn-primary btn-lg btn-block">
				Kirjaudu sisään <span class="glyphicon glyphicon-log-in"></span>
			</button>
		</div>
	</form>
</div>