<h1>Kurssit</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam vitae, illo amet ipsam dicta quis animi provident facere maxime quos perspiciatis laboriosam, quia expedita nihil ex quo, ipsum repellat. Nam nisi modi ea tempora harum atque deleniti, commodi ab ex inventore unde accusamus laboriosam consequatur aspernatur similique explicabo sed sequi.</p>
<?php foreach($series as $item): ?>
	<div class="series">
		<h3><a href="/series/<?php echo $item->id; ?>"><?php echo $item->title; ?></a></h3>
		<div class="description">
			<?php echo $item->description; ?>
		</div>
	</div>
<?php endforeach; ?>