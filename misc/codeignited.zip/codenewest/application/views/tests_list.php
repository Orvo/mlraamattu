<a href="/" class="btn btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Takaisin pääsivulle</a>

<h1>Kurssikokeet</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam vitae, illo amet ipsam dicta quis animi provident facere maxime quos perspiciatis laboriosam, quia expedita nihil ex quo, ipsum repellat. Nam nisi modi ea tempora harum atque deleniti, commodi ab ex inventore unde accusamus laboriosam consequatur aspernatur similique explicabo sed sequi.</p>
<?php foreach($tests as $item): ?>
	<div class="test">
		<h3><a href="/test/<?php echo $item->id; ?>"><?php echo $item->title; ?></a></h3>
		<div class="description">
			<?php echo $item->description; ?>
		</div>
	</div>
<?php endforeach; ?>