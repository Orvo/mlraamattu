<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Questionnaire_model extends CI_Model
{

	public function __construct()
	{
		// Call the CI_Model constructor
		parent::__construct();
	}

	public function get_question_and_choices($id)
	{
		$question = $this->db->where('id', $id)->get('questions');
		$choices = $this->db->where('question_id', $id)->get('choices');
		
		return array("question" => $question->row(), "choices" => $choices->result_object());
	}
	
	public function get_tests()
	{
		return $this->db->get('tests')->result();
	}
	
	public function get_test_questions($id)
	{
		$questions = $this->db->select('questions.id, questions.type, questions.title, questions.subtitle')
							  ->join('questions', 'questions.id = test_questions.question_id')
							  ->where('test_id', $id)
							  ->order_by('order', 'ASC')
							  ->get('test_questions');
		
		if($questions->num_rows() == 0) return false;
			  
		$choices = $this->db->select('choices.id, choices.question_id, choices.text, choices.is_correct')
							->join('choices', 'test_questions.question_id = choices.question_id')
							->where('test_id', $id)
							->get('test_questions');
		
		$indexed_choices = array();
		foreach($choices->result_object() as $choice)
		{
			$indexed_choices[$choice->question_id][] = $choice;
		}
		
		$questions_array = $questions->result_object();
		foreach($questions_array as $key => $question)
		{
			$questions_array[$key]->number = $key + 1;
			
			if(array_key_exists($question->id, $indexed_choices))
			{
				$questions_array[$key]->choices = $indexed_choices[$question->id];
			}
			
			if($question->type == "MULTITEXT")
			{
				$answers = $this->db->get_where('answers', array('question_id' => $question->id));
				$questions_array[$key]->num_answers = max(1, $answers->num_rows());
			}
		}
		
		return $questions_array;
	}

	public function validate_answer($question_id, $given_answer)
	{
		$question = $this->db->where('id', $question_id)->get('questions');

		switch($question->row()->type)
		{
			case 'MULTI':
				$matched = array();
				$choices = $this->db->get_where('choices', array('question_id' => $question_id, 'is_correct' => 1));

				if($choices)
				{
					foreach($choices->result() as $choice)
					{
						if(in_array($choice->id, $given_answer))
						{
							// return false;
							$matched[] = $choice->id;
						}
					}

					// if($choices->num_rows() != count($given_answer)) return false;

					return array(
						"correct" 	=> count($matched) == $choices->num_rows() && $choices->num_rows() == count($given_answer),
						"partial" 	=> count($matched),
						"total"		=> $choices->num_rows(),
					);
				}
			break;

			case 'CHOICE':
				$choices = $this->db->get_where('choices', array('question_id' => $question_id, 'is_correct' => 1, 'id' => $given_answer));
				
				return array(
					"correct" => $choices->num_rows() != 0,
				);
			break;

			case 'TEXT':
				$answers = $this->db->get_where('answers', array('question_id' => $question_id));

				if($answers->num_rows() == 1)
				{
					$answer = $answers->row();
					
					return array(
						"correct" => $this->_string_match($answer->text, $given_answer, $answer->error_margin),
					);
				}
			break;
			
			case 'MULTITEXT':
				$matched = array();
				$answers = $this->db->get_where('answers', array('question_id' => $question_id));
				
				foreach($answers->result() as $correct_answer)
				{
					foreach($given_answer as $key => $answer)
					{
						if($this->_string_match($correct_answer->text, $answer, $correct_answer->error_margin))
						{
							$matched[] = $answer;
							unset($given_answer[$key]);
							break;
						}
					}
				}
				
				return array(
					"correct" 	=> count($matched) == $answers->num_rows(),
					"partial" 	=> count($matched),
					"total"		=> $answers->num_rows(),
				);
			break;
			
			case 'TEXTAREA':
				return array(
					"correct" => true,
				);
			break;
		}

		return false;
	}
	
	private function _string_match($str1, $str2, $margin)
	{
		$str1 = mb_strtoupper($this->_strip_punctuation($str1));
		$str2 = mb_strtoupper($this->_strip_punctuation($str2));

		if($margin > 0)
		{
			$margin = ceil(strlen($str1) * ($margin / 100.0));
			return levenshtein($str1, $str2) <= $margin;
		}
		
		return $str1 == $str2;
	}
	
	private function _strip_punctuation($str)
	{
		return trim(str_replace(str_split('!\'\\"#€%&/()=?+-.,;:_@$£∞§|[]<>'), '', $str));
	}
}