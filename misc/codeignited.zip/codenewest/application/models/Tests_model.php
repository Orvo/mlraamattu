<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Tests_model extends CI_Model
{

	public function __construct()
	{
		// Call the CI_Model constructor
		parent::__construct();
	}

	public function get($id = false)
	{
		if($id !== false && is_numeric($id))
		{
			return $this->db->get_where('tests', array('id' => $id))->row();
		}
		else
		{
			return $this->db->get('tests')->result();
		}
	}
	
	public function get_questions($id)
	{
		if(!$id || !is_numeric($id)) return false;
		
		$tests = $this->db
					->select('questions.id, questions.type, questions.title, questions.subtitle')
					->join('questions', 'questions.id = test_questions.question_id')
					->where('test_id', $id)
					->order_by('test_questions.order', 'ASC')
					->get('test_questions');
		
		return $tests->result();
	}
	
	public function get_questions_with_choices($id)
	{
		if(!$id || !is_numeric($id)) return false;
		
		$questions = $this->db->select('questions.id, questions.type, questions.title, questions.subtitle')
							  ->join('questions', 'questions.id = test_questions.question_id')
							  ->where('test_id', $id)
							  ->order_by('order', 'ASC')
							  ->get('test_questions');
		
		if($questions->num_rows() == 0) return false;
			  
		$choices = $this->db->select('choices.id, choices.question_id, choices.text, choices.is_correct')
							->join('choices', 'test_questions.question_id = choices.question_id')
							->where('test_id', $id)
							->get('test_questions');
		
		$indexed_choices = array();
		foreach($choices->result_object() as $choice)
		{
			$indexed_choices[$choice->question_id][] = $choice;
		}
		
		$questions_array = $questions->result_object();
		foreach($questions_array as $key => $question)
		{
			$questions_array[$key]->number = $key + 1;
			
			if(array_key_exists($question->id, $indexed_choices))
			{
				$questions_array[$key]->choices = $indexed_choices[$question->id];
			}
			
			if($question->type == "MULTITEXT")
			{
				$answers = $this->db->get_where('answers', array('question_id' => $question->id));
				$questions_array[$key]->num_answers = max(1, $answers->num_rows());
			}
		}
		
		return $questions_array;
	}
	
	public function get_full_test($id)
	{
		if(!$id || !is_numeric($id)) return false;

		$test = $this->db->where('id', $id)
						 ->get('tests');

		if($test->num_rows() == 0) return false;

		$test = $test->row();
		
		$questions = $this->db->select('questions.id, questions.type, questions.title, questions.subtitle')
							  ->join('questions', 'questions.id = test_questions.question_id')
							  ->where('test_id', $id)
							  ->order_by('order', 'ASC')
							  ->get('test_questions');
		
		if($questions->num_rows() == 0) return false;
			  
		$choices = $this->db->select('choices.id, choices.question_id, choices.text, choices.is_correct')
							->join('choices', 'test_questions.question_id = choices.question_id')
							->where('test_id', $id)
							->get('test_questions');
		
		$indexed_choices = array();
		foreach($choices->result_object() as $choice)
		{
			if($choice->is_correct == "1")
			{
				$choice->is_correct = true;
			}
			else
			{
				$choice->is_correct = false;
			}

			$indexed_choices[$choice->question_id][] = $choice;
		}
		
		$questions_array = $questions->result_object();
		foreach($questions_array as $key => $question)
		{
			$questions_array[$key]->number = $key + 1;
			
			if(array_key_exists($question->id, $indexed_choices))
			{
				$questions_array[$key]->choices = $indexed_choices[$question->id];
			}
			
			if($question->type == "CHOICE")
			{
				foreach($questions_array[$key]->choices as $choice)
				{
					if($choice->is_correct)
					{
						$questions_array[$key]->correct = $choice->id;
						break;
					}
				}
			}
			elseif($question->type == "MULTITEXT")
			{
				$answers = $this->db->get_where('answers', array('question_id' => $question->id));

				$questions_array[$key]->num_answers = max(1, $answers->num_rows());
				$questions_array[$key]->answers = $answers->result_array();
			}
			elseif($question->type == "TEXT")
			{
				$answers = $this->db->get_where('answers', array('question_id' => $question->id));

				$questions_array[$key]->num_answers = max(1, $answers->num_rows());
				$questions_array[$key]->answer = $answers->row();
			}
		}
		
		$test->questions = $questions_array;

		// header("Content-type: text/plain");
		// print_r($test);

		return $test;
	}

	public function validate_answer($question_id, $given_answer)
	{
		$question = $this->db->where('id', $question_id)->get('questions');

		switch($question->row()->type)
		{
			case 'MULTI':
				$matched = array();
				$choices = $this->db->get_where('choices', array('question_id' => $question_id, 'is_correct' => 1));

				if($choices)
				{
					foreach($choices->result() as $choice)
					{
						if(in_array($choice->id, $given_answer))
						{
							// return false;
							$matched[] = $choice->id;
						}
					}

					// if($choices->num_rows() != count($given_answer)) return false;

					return array(
						"correct" 	=> count($matched) == $choices->num_rows() && $choices->num_rows() == count($given_answer),
						"partial" 	=> count($matched),
						"total"		=> $choices->num_rows(),
					);
				}
			break;

			case 'CHOICE':
				$choices = $this->db->get_where('choices', array('question_id' => $question_id, 'is_correct' => 1, 'id' => $given_answer));
				
				return array(
					"correct" => $choices->num_rows() != 0,
				);
			break;

			case 'TEXT':
				$answers = $this->db->get_where('answers', array('question_id' => $question_id));

				if($answers->num_rows() == 1)
				{
					$answer = $answers->row();
					
					return array(
						"correct" => $this->_string_match($answer->text, $given_answer, $answer->error_margin),
					);
				}
			break;
			
			case 'MULTITEXT':
				$matched = array();
				$answers = $this->db->get_where('answers', array('question_id' => $question_id));
				
				foreach($answers->result() as $correct_answer)
				{
					foreach($given_answer as $key => $answer)
					{
						if($this->_string_match($correct_answer->text, $answer, $correct_answer->error_margin))
						{
							$matched[] = $answer;
							unset($given_answer[$key]);
							break;
						}
					}
				}
				
				return array(
					"correct" 	=> count($matched) == $answers->num_rows(),
					"partial" 	=> count($matched),
					"total"		=> $answers->num_rows(),
				);
			break;
			
			case 'TEXTAREA':
				return array(
					"correct" => true,
				);
			break;
		}

		return false;
	}
	
	private function _string_match($str1, $str2, $margin)
	{
		$str1 = mb_strtoupper($this->_strip_punctuation($str1));
		$str2 = mb_strtoupper($this->_strip_punctuation($str2));

		if($margin > 0)
		{
			$margin = ceil(strlen($str1) * ($margin / 100.0));
			return levenshtein($str1, $str2) <= $margin;
		}
		
		return $str1 == $str2;
	}
	
	private function _strip_punctuation($str)
	{
		return trim(str_replace(str_split('!\'\\"#€%&/()=?+-.,;:_@$£∞§|[]<>'), '', $str));
	}
	
}