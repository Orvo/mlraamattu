<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Series_model extends CI_Model
{

	public function __construct()
	{
		// Call the CI_Model constructor
		parent::__construct();
	}

	public function get($id = false)
	{
		if($id !== false && is_numeric($id))
		{
			return $this->db->get_where('series', array('id' => $id))->row();
		}
		else
		{
			return $this->db->get('series')->result();
		}
	}
	
	public function get_tests($id)
	{
		$tests = $this->db
					->select('series_id, test_id AS id, title, description')
					->join('tests', 'tests.id = series_tests.test_id')
					->where('series_id', $id)
					->order_by('series_tests.order', 'ASC')
					->get('series_tests');
		
		return $tests->result();
	}
	
}