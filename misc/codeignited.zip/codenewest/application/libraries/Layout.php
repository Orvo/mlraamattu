<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Layout
{
    
    var $CI;
    
    function Layout()
    {
        $this->CI = &get_instance();
    }
    
    function view($view, $data = array())
    {
        $data['AUTH'] = $this->CI->auth->data();

        $data['_PAGE_CONTENT'] = $this->CI->load->view($view, $data, true);
        $this->CI->load->view("layout/main", $data);
    }
    
    function admin($view, $data = array())
    {
        $data['AUTH'] = $this->CI->auth->data();

		$data['_PAGE_CONTENT'] = $this->CI->load->view($view, $data, true);
		$this->CI->load->view("layout/admin", $data);
    }
}