<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Auth
{
	
	var $CI;
	
	function Auth()
	{
		$this->CI = &get_instance();
	}
	
	function check()
	{
		if($this->CI->session->logged_in && $this->identifier() == $this->CI->session->identifier)
		{
			return true;
		}
		else
		{
			$this->logout();
			return false;
		}
	}
	
	function check_admin()
	{
		if($this->check())
		{
			$data = $this->data();
			return $data->user->access == 1;
		}
		else
		{
			return false;
		}
	}
	
	function exists($email)
	{
		$users = $this->CI->db->get_where('users', array('email' => $email));
		return $users->num_rows() > 0;
	}

	function create($email, $password, $custom_data = array())
	{
		if($this->exists($email)) return false;

		$data = array(
			'email'		=> $email,
			'password'	=> $this->hash($password),
		);

		$data = array_merge($custom_data, $data);

		$this->CI->db->insert('users', $data);

		return true;
	}

	function login($email, $password)
	{
		if($this->check()) return false;

		$user = $this->CI->db->get_where('users', array('email' => $email), 1);
		if($user->num_rows() > 0)
		{
			$user = $user->row();

			if($this->match($password, $user->password))
			{
				$data = array(
					'email' 		=> $user->email,
					'logged_in'		=> true,
					'identifier'	=> $this->identifier(),
				);

				$this->CI->session->set_userdata($data);

				return true;
			}
		}

		return false;
	}

	function logout()
	{
		unset($_SESSION['email']);
		unset($_SESSION['logged_in']);
		unset($_SESSION['identifier']);
	}

	function data()
	{
		if(!$this->check()) return false;

		$user = $this->CI->db->get_where('users', array('email' => $this->CI->session->email), 1);

		return (object)array(
			'email' 	=> $this->CI->session->email,
			'logged_in' => $this->CI->session->logged_in,
			'user'		=> $user->row(),
		);
	}

	function identifier()
	{
		return sha1($_SERVER['REMOTE_ADDR'] . '/' . $_SERVER['HTTP_USER_AGENT']);
	}

	function hash($password)
	{
		return password_hash($password, PASSWORD_DEFAULT);
	}

	function match($password, $hash)
	{
		return password_verify($password, $hash);
	}
}