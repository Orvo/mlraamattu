<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller
{

	public function index($test_id = 1)
	{
		// $this->auth->create('test', 'test');
		// $this->auth->login('test', 'test');

		// header("Content-type: text/plain");
		// print_r($this->series_model->get());
		
		// die;
		
		$data = array(
			'series' => $this->series_model->get(),
		);
		
		$this->layout->view('series_list', $data);
	}
	
}
