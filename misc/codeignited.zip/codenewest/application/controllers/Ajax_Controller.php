<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax_Controller extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		if(!$this->auth->check_admin()) return "No access";
	}

	public function get_series($id = false)
	{
		if(!$this->auth->check_admin()) return "No access";
		$this->json($this->series_model->get($id));
	}

	public function get_tests($id = false)
	{
		if(!$this->auth->check_admin()) return "No access";
		$this->json($this->tests_model->get($id));
	}

	public function get_test_questions($id = false)
	{
		if(!$this->auth->check_admin()) return "No access";
		$this->json($this->tests_model->get_questions($id));
	}

	public function get_full_test($id)
	{
		if(!$this->auth->check_admin()) return "No access";
		$this->json($this->tests_model->get_full_test($id));
	}

	public function get_questions($id = false)
	{
		if(!$this->auth->check_admin()) return "No access";
		
		if($id === false || !is_numeric($id))
		{
			$questions = $this->db->get('questions');
			$this->json($questions->result_array());
		}
		else
		{
			$questions = $this->db->get_where('questions', array('id' => $id));
			$this->json($questions->result_array());
		}
	}
	
}
