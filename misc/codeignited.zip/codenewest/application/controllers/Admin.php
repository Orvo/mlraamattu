<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller
{

	public function index()
	{
		if(!$this->auth->check()) redirect('/');
		
		$this->layout->admin('admin/index');
	}

	public function check()
	{
		if($this->auth->check()) redirect('/');
		
		$data = array(
			'email' => $this->input->post('email'),
		);
		
		$password 	= $this->input->post('password');
		
		$data['login_success']	= $this->auth->login($data['email'], $password);
		
		if($data['login_success'])
		{
			redirect('/');
		}
		
		$this->layout->view('login', $data);
	}

	public function logout()
	{
		$this->auth->logout();
		redirect('/');
	}
	
}
