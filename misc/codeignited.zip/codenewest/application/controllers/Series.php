<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Series extends CI_Controller
{

	public function index($id = 1)
	{
		$data = array(
			'tests'	=> $this->series_model->get_tests($id),
		);
		
		$this->layout->view('tests_list', $data);
	}
	
}
