<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller
{

	public function index($test_id = 1)
	{
		$questions = $this->tests_model->get_questions_with_choices($test_id);
		
		if($questions === false)
		{
			echo "Not found";
			return;
		}
		
		foreach($questions as $question)
		{
			$question->validation = null;
			$question->answers = false;
		}
		
		$test = $this->db->get_where('tests', array('id' => $test_id))->row();

		$data = array(
			'test_id'		=> $test_id,
			'test'			=> $test,
			'questions' 	=> $questions,
		);
		
		$this->layout->view('questionnaire', $data);
	}
	
	public function check($test_id)
	{
		if($test_id != $this->input->post('test_id'))
		{
			echo "Invalid test ID";
			return;
		}
		
		$answers = array();
		$correct = array();
		$question_ids = $this->input->post('questions');
		
		foreach($question_ids as $id)
		{
			$answer = $this->input->post('answer-' . $id);
			if(!$answer || (!is_array($answer) && strlen($answer) == 0) || (is_array($answer) && count($answer) == 0))
			{
				$answer = false;
			}

			$validation[$id] = false;

			if($answer !== false)
			{
				$answers[$id] = $answer;
				$validation[$id] = $this->tests_model->validate_answer($id, $answer);
			}
		}
		
		$questions = $this->tests_model->get_questions_with_choices($test_id);
		
		foreach($questions as $question)
		{
			$question->validation = array_key_exists($question->id, $validation) ? $validation[$question->id] : null;
			$question->answers = array_key_exists($question->id, $answers) ? $answers[$question->id] : false;
		}
		
		$test = $this->db->get_where('tests', array('id' => $test_id))->row();

		$data = array(
			'test_id'		=> $test_id,
			'test'			=> $test,
			'questions' 	=> $questions,
		);
		
		if(!$this->auth->check())
		{
			$errors = array();
			
			$email 		= $this->input->post('user-email');
			$password1 	= $this->input->post('user-password1');
			$password2 	= $this->input->post('user-password2');
			
			if(!filter_var($email, FILTER_VALIDATE_EMAIL))
			{
				$errors[] = "Sähköposti ei ole toimiva osoite.";
			}
			
			if(strlen($password1) < 8)
			{
				$errors[] = "Salasanan tulee olla ainakin 8 merkkiä pitkä.";
			}
			elseif($password1 != $password2)
			{
				$errors[] = "Salasanat eivät täsmää.";
			}
			
			if($this->auth->exists($email))
			{
				$errors[] = "Käyttäjätunnus sähköpostiosoitteella on jo olemassa. Kirjaudu sisään!";
			}
			
			if(count($errors) > 0)
			{
				$data['errors'] = $errors;
				$data['fields'] = array(
					'email' => $email,
				);
			}
			else
			{
				if($this->auth->create($email, $password1))
				{
					$this->auth->login($email, $password1);
				}
			}
		}
		
		$this->layout->view('questionnaire', $data);
	}
	
	private function _generate_questionnaire_code($test_id, $answers = array(), $validation = array())
	{
		$questions = $this->tests_model->get_questions_with_choices($test_id);
		
		if($questions === false) return false;
		
		ob_start();
		
		foreach($questions as $question)
		{
			$this->load->view('output_question', array(
				'question' 		=> $question,
				'answers'		=> array_key_exists($question->id, $answers) ? $answers[$question->id] : false,
				'validation'	=> array_key_exists($question->id, $validation) ? $validation[$question->id] : null,
			));
		}
		
		$code = ob_get_clean();
		
		return $code;
	}
	
}
